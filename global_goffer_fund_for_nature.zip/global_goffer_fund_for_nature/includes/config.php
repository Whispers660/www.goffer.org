<?php
session_start();

// --- SITE METADATA ---
define('SITE_NAME', 'Global Goffer Fund for Nature');

// --- SECURITY HEADERS (also set in header.php but duplicating as a safety measure) ---
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer-when-downgrade');

// --- DATABASE (SQLite by default) ---
// Location: data/database.sqlite
$db_path = __DIR__ . '/../data/database.sqlite';
$dsn = 'sqlite:' . $db_path;

try {
    $pdo = new PDO($dsn, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Exception $e) {
    // In production - log the error and show a generic message
    die('Database connection failed: ' . htmlspecialchars($e->getMessage()));
}

// --- CSRF helpers ---
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function csrf_check($token) {
    return hash_equals($_SESSION['csrf_token'] ?? '', $token ?? '');
}

// --- File upload settings ---
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_UPLOAD_BYTES', 5 * 1024 * 1024); // 5 MB
$ALLOWED_EXT = ['pdf','doc','docx','png','jpg','jpeg','csv','xlsx','txt'];
$ALLOWED_MIME = [
    'application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'image/png','image/jpeg','text/csv','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','text/plain'
];

?>
<?php
if (!defined('SITE_NAME')) require_once __DIR__ . '/config.php';
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="description" content="Global Goffer Fund for Nature — financing conservation and coordination globally.">
  <meta name="author" content="Global Goffer Fund for Nature">
  <meta name="robots" content="index,follow">
  <!-- Security-related -->
  <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; img-src 'self' data:;">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo htmlspecialchars(SITE_NAME); ?></title>
  <!-- Bootstrap 5 (via CDN) -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="" crossorigin="anonymous">
  <link rel="stylesheet" href="/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="/index.php"><?php echo htmlspecialchars(SITE_NAME); ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="/institutional.php">Institutional Framework</a></li>
        <li class="nav-item"><a class="nav-link" href="/accreditation.php">Accreditation</a></li>
        <li class="nav-item"><a class="nav-link" href="/coordination.php">Coordination</a></li>
        <li class="nav-item"><a class="nav-link" href="/private_offers.php">Private Placement Offers</a></li>
        <li class="nav-item"><a class="nav-link" href="/itinerary.php">Itinerary Shares</a></li>
        <li class="nav-item"><a class="nav-link" href="/register.php">Registration</a></li>
        <li class="nav-item"><a class="nav-link" href="/uploads.php">Uploads</a></li>
      </ul>
    </div>
  </div>
</nav>

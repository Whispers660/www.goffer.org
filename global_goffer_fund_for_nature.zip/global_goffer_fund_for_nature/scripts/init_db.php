<?php
// Initialize SQLite database and create tables
require_once __DIR__ . '/../includes/config.php';

// Create users table
$pdo->exec("""CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fullname TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  organisation TEXT,
  created_at TEXT
)""");

// Create uploads table
$pdo->exec("""CREATE TABLE IF NOT EXISTS uploads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  original_name TEXT NOT NULL,
  stored_name TEXT NOT NULL,
  description TEXT,
  uploaded_at TEXT
)""");
echo "Database initialized.\n";

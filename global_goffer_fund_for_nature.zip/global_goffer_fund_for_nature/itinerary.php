<?php
require_once __DIR__ . '/includes/config.php';
include __DIR__ . '/includes/header.php';
?>
<main class="container py-5">
  <h1>Itinerary Shares</h1>
  <p class="lead">Content for the Itinerary Shares page. Replace with real content for your organization.</p>
  <div class="card p-3 mt-3">
    <h5>Overview</h5>
    <p>Describe objectives, policies, procedures, and governance structures here.</p>
  </div>
</main>
<?php include __DIR__ . '/includes/footer.php'; ?>